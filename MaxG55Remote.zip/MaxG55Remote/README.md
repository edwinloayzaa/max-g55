# Control Samsung MAX-G55 (APK con WebView + emisor IR)
Ver instrucciones en el chat. Para compilar con Android Studio: abre esta carpeta y usa Build > Build APK(s).
Ajusta códigos en la app (Modo edición / Explorador) o en app/src/main/assets/app.js.

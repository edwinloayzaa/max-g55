// Tabla de códigos. Formatos aceptados por cada tecla:
//   '0xE0E040BF'  -> notación "en el aire" Samsung32 (MSB primero)
//   'S32:02:46'   -> protocolo Samsung32, dirección 02, comando 46 (estándar Flipper)
//   'NEC:00FF:12' -> protocolo NEC, dirección de 16 bits 00FF, comando 12
// ⚠️ Los de abajo están SIN VERIFICAR para el MAX-G55 (ver Explorador / Modo edición).
const codigosSamsung = {
    'POWER': '0xE0E040BF',
    'SRC_TUNER': '0x4040629D',
    'SRC_CD': '0x404012ED',
    'SRC_USB': '0x404022DD',
    'SRC_AUX': '0x4040A25D',

    'NUM_1': '0xE0E020DF',
    'NUM_2': '0xE0E0A05F',
    'NUM_3': '0xE0E0609F',
    'NUM_4': '0xE0E010EF',
    'NUM_5': '0xE0E0906F',
    'NUM_6': '0xE0E050AF',
    'NUM_7': '0xE0E030CF',
    'NUM_8': '0xE0E0B04F',
    'NUM_9': '0xE0E0708F',
    'NUM_10_PLUS': '0x404052AD',
    'NUM_0': '0xE0E08877',
    'ENTER': '0xE0E016E9',

    'VOL_UP': '0xE0E0E01F',
    'MUTE': '0xE0E0F00F',
    'VOL_DOWN': '0xE0E0D02F',
    'NAV_UP': '0xE0E006F9',
    'NAV_DOWN': '0xE0E08679',
    'NAV_LEFT': '0xE0E0A659',
    'NAV_RIGHT': '0xE0E046B9',
    'NAV_OK': '0x4040F20D',

    'MEDIA_PREV': '0x404002FD',
    'MEDIA_PLAY': '0xE0E0E21D',
    'MEDIA_PAUSE': '0x404052AF',
    'MEDIA_STOP': '0x404012ED',
    'MEDIA_NEXT': '0x4040827D',
    'PLAY_MODE': '0x4040926D',
    'REPEAT': '0x4040D22D',
    'DISPLAY': '0x404032CD',

    'P_EQ': '0x4040728D',
    'GigaSound': '0x4040B24D',
    'SLEEP': '0x404006F9',
    'TIMER': '0x40408679',
    'CLOCK': '0x404046B9',
    'DEMO': '0x4040C639'
};

const STORAGE_KEY = 'codigosPersonalizados';
const VIB_KEY = 'vibracion';
const REPETIBLES = new Set(['VOL_UP', 'VOL_DOWN', 'NAV_LEFT', 'NAV_RIGHT']);
const REP_KEY = 'repeticiones';
// Comandos "típicos" que se prueban en la búsqueda rápida: los de un TV Samsung (power, vol+, vol-, mute)
// y un bloque 0x40-0x4A que aparece en tu tabla original. Es una heurística, no un dato confirmado.
const PROBES = [0x02, 0x07, 0x0B, 0x0F, 0x40, 0x41, 0x44, 0x46, 0x48, 0x4A];
const RE_HEX = /^0x[0-9a-f]{8}$/i;
const RE_PROTO = /^(S32|NEC):([0-9a-f]{2}|[0-9a-f]{4}):([0-9a-f]{2})$/i;

let modoEdicion = false;
let claveEditando = null;
let vibracionOn = true;
let repeticiones = 1;
try { repeticiones = Math.min(3, Math.max(1, parseInt(localStorage.getItem(REP_KEY) || '1', 10) || 1)); } catch (e) {}
function aplicarRepeticiones() { try { if (window.AndroidIR && window.AndroidIR.setRepeats) window.AndroidIR.setRepeats(repeticiones); } catch (e) {} }
try { vibracionOn = localStorage.getItem(VIB_KEY) !== 'off'; } catch (e) {}

// ---------- utilidades ----------
function leerOverrides() { try { return JSON.parse(localStorage.getItem(STORAGE_KEY) || '{}'); } catch (e) { return {}; } }
function guardarOverrides(o) { try { localStorage.setItem(STORAGE_KEY, JSON.stringify(o)); } catch (e) {} }
function codigoDe(b) { return leerOverrides()[b] || codigosSamsung[b]; }
function h2(n) { return n.toString(16).toUpperCase().padStart(2, '0'); }
function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

function vibrar(tipo) {
    if (vibracionOn && window.AndroidIR && window.AndroidIR.haptic) {
        try { window.AndroidIR.haptic(tipo); } catch (e) {}
    }
}

let toastTimer;
function toast(msg) {
    const t = document.getElementById('toast');
    t.textContent = msg;
    t.classList.add('show');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => t.classList.remove('show'), 2200);
}

// 4 bytes (cmd + ~cmd) según protocolo y dirección de 2 o 4 dígitos
function bytesDe(proto, addrHex, cmdHex) {
    const c = parseInt(cmdHex, 16) & 255;
    let b0, b1;
    if (addrHex.length === 4) {
        const v = parseInt(addrHex, 16);
        b0 = v & 255; b1 = (v >> 8) & 255;
    } else {
        const a = parseInt(addrHex, 16) & 255;
        b0 = a; b1 = (proto === 'NEC') ? ((~a) & 255) : a;
    }
    return [b0, b1, c, (~c) & 255];
}

function enviarProto(proto, addrHex, cmdHex) {
    const b = bytesDe(proto, addrHex, cmdHex);
    return window.AndroidIR.sendProto(proto, b[0], b[1], b[2], b[3]);
}

function enviarCodigo(codigo) {
    if (RE_HEX.test(codigo)) return window.AndroidIR.send(codigo);
    const m = RE_PROTO.exec(codigo);
    if (!m) return 'bad_hex';
    return enviarProto(m[1].toUpperCase(), m[2], m[3]);
}

function normalizarCodigo(s) {
    s = (s || '').trim();
    if (RE_HEX.test(s)) return '0x' + s.slice(2).toUpperCase();
    if (RE_PROTO.test(s)) return s.toUpperCase();
    return null;
}

function mensajeResultado(nombre, r) {
    if (r === 'ok') return nombre + ' ✔';
    if (r === 'warn_checksum') return nombre + ' enviado, pero el código parece inválido (checksum)';
    if (r === 'bad_hex') return 'Código mal escrito';
    if (r === 'no_emitter') return 'Este teléfono no tiene emisor IR';
    return 'Error IR: ' + String(r).replace(/^error:/, '');
}

function enviarSenal(boton, silencioso) {
    const codigo = codigoDe(boton);
    if (!codigo) { toast('Sin código para ' + boton); return; }
    if (!window.AndroidIR) { if (!silencioso) toast('Vista previa: ' + boton + ' → ' + codigo); return; }
    const r = enviarCodigo(codigo);
    if (r !== 'ok') vibrar('error');
    if (silencioso && r === 'ok') return;
    toast(mensajeResultado(boton, r));
}

// ---------- Modal de edición ----------
function abrirEditor(clave) {
    claveEditando = clave;
    document.getElementById('modal-titulo').textContent = 'Código de ' + clave;
    document.getElementById('modal-actual').textContent =
        'Actual: ' + codigoDe(clave) + '  |  Original: ' + codigosSamsung[clave];
    document.getElementById('modal-input').value = codigoDe(clave);
    document.getElementById('modal').hidden = false;
}
function cerrarEditor() { document.getElementById('modal').hidden = true; claveEditando = null; }
function guardarEditor() {
    const v = normalizarCodigo(document.getElementById('modal-input').value);
    if (!v) { toast('Formato: 0xE0E040BF  o  S32:02:46  o  NEC:00FF:12'); return; }
    const o = leerOverrides(); o[claveEditando] = v; guardarOverrides(o);
    const k = claveEditando;
    cerrarEditor(); toast('Guardado ' + k); enviarSenal(k, true);
}
function restaurarEditor() {
    const o = leerOverrides(); delete o[claveEditando]; guardarOverrides(o);
    cerrarEditor(); toast('Restaurado');
}

// ---------- Inicio ----------
document.addEventListener('DOMContentLoaded', () => {
    const $ = id => document.getElementById(id);

    // Estado + diagnóstico
    const estado = $('estado');
    if (window.AndroidIR) {
        if (window.AndroidIR.hasEmitter()) { estado.textContent = 'Emisor IR detectado ✔'; estado.className = 'estado ok'; }
        else { estado.textContent = 'Este teléfono no tiene emisor IR ✖'; estado.className = 'estado mal'; }
        try { $('diag').textContent = window.AndroidIR.info(); } catch (e) { $('diag').textContent = 'Sin diagnóstico'; }
    } else {
        estado.textContent = 'Vista previa en navegador (sin IR)';
        $('diag').textContent = 'Sin puente Android';
    }

    // Vibración en cualquier botón que no sea una tecla del control (herramientas, explorador, modal)
    document.addEventListener('pointerdown', e => {
        const b = e.target.closest && e.target.closest('button');
        if (b && !b.dataset.key) vibrar('click');
    });

    // Teclas del control
    document.querySelectorAll('button[onclick]').forEach(btn => {
        const m = /enviarSenal\('([^']+)'\)/.exec(btn.getAttribute('onclick'));
        if (!m) return;
        const clave = m[1];
        btn.removeAttribute('onclick');
        btn.dataset.key = clave;

        let tRep = null, iRep = null, repitio = false;
        const parar = () => { clearTimeout(tRep); clearInterval(iRep); };

        btn.addEventListener('pointerdown', () => {
            repitio = false;
            vibrar(clave === 'POWER' ? 'heavy' : 'click');
            if (!modoEdicion && REPETIBLES.has(clave)) {
                tRep = setTimeout(() => {
                    repitio = true;
                    enviarSenal(clave, true); vibrar('tick');
                    iRep = setInterval(() => { enviarSenal(clave, true); vibrar('tick'); }, 150);
                }, 400);
            }
        });
        ['pointerup', 'pointercancel', 'pointerleave'].forEach(ev => btn.addEventListener(ev, parar));

        btn.addEventListener('click', () => {
            if (repitio) { repitio = false; return; }
            if (modoEdicion) abrirEditor(clave); else enviarSenal(clave);
        });
    });

    // Herramientas
    const bv = $('btn-vib');
    const pintarVib = () => { bv.textContent = '📳 Vibración: ' + (vibracionOn ? 'ON' : 'OFF'); };
    pintarVib();
    bv.addEventListener('click', () => {
        vibracionOn = !vibracionOn;
        try { localStorage.setItem(VIB_KEY, vibracionOn ? 'on' : 'off'); } catch (e) {}
        pintarVib();
        if (vibracionOn) vibrar('heavy');
    });

    aplicarRepeticiones();
    const br = $('btn-rep');
    const pintarRep = () => { br.textContent = '🔁 Repeticiones por pulsación: ' + repeticiones; };
    pintarRep();
    br.addEventListener('click', () => {
        repeticiones = repeticiones % 3 + 1;
        try { localStorage.setItem(REP_KEY, String(repeticiones)); } catch (e) {}
        aplicarRepeticiones(); pintarRep();
        toast('Cada pulsación enviará ' + repeticiones + (repeticiones === 1 ? ' trama' : ' tramas'));
    });

    const be = $('btn-edit');
    be.addEventListener('click', () => {
        modoEdicion = !modoEdicion;
        document.body.classList.toggle('editando', modoEdicion);
        be.classList.toggle('on', modoEdicion);
        be.textContent = '✎ Modo edición de códigos: ' + (modoEdicion ? 'ON (toca un botón)' : 'OFF');
    });

    $('btn-test-tv').addEventListener('click', () => {
        if (!window.AndroidIR) { toast('Solo disponible en el APK'); return; }
        const r = window.AndroidIR.send('0xE0E040BF');   // POWER de TV Samsung (código verificado)
        toast(r === 'ok' ? 'Enviado POWER de TV Samsung. ¿Reaccionó el TV?' : mensajeResultado('Prueba', r));
    });

    let ledTimer = null;
    $('btn-test-led').addEventListener('click', () => {
        if (!window.AndroidIR) { toast('Solo disponible en el APK'); return; }
        if (ledTimer) return;
        toast('Mira el emisor con la cámara de OTRO celular: debe verse un destello');
        const fin = Date.now() + 4000;
        ledTimer = setInterval(() => {
            if (Date.now() > fin) { clearInterval(ledTimer); ledTimer = null; return; }
            enviarProto('NEC', '59', '12');
        }, 150);
    });

    // Modal
    $('modal-guardar').addEventListener('click', guardarEditor);
    $('modal-reset').addEventListener('click', restaurarEditor);
    $('modal-cancelar').addEventListener('click', cerrarEditor);

    // ---------- Explorador ----------
    const addrIn = $('sc-addr'), cmdIn = $('sc-cmd'), info = $('sc-info'), sel = $('sc-key');
    let autoTimer = null, findToken = 0, probeIdx = 0;

    Object.keys(codigosSamsung).forEach(k => {
        const o = document.createElement('option'); o.value = k; o.textContent = k; sel.appendChild(o);
    });

    const proto = () => $('sc-proto').value;
    function leerAddr() {
        const s = addrIn.value.trim();
        return /^([0-9a-f]{2}|[0-9a-f]{4})$/i.test(s) ? s.toUpperCase() : null;
    }
    function leerCmd() {
        const s = cmdIn.value.trim();
        return /^[0-9a-f]{2}$/i.test(s) ? s.toUpperCase() : null;
    }
    function enviarEscaneo(a, c) {
        const b = bytesDe(proto(), a, c);
        info.textContent = proto() + '  dir ' + a + '  cmd ' + c + '\nbytes: ' + b.map(h2).join(' ') +
            '\ncódigo: ' + proto() + ':' + a + ':' + c;
        if (window.AndroidIR) return window.AndroidIR.sendProto(proto(), b[0], b[1], b[2], b[3]);
        return 'ok';
    }
    function enviarActual() {
        const a = leerAddr(), c = leerCmd();
        if (!a || !c) { toast('Dirección 2/4 dígitos y comando 2 dígitos (hex)'); return false; }
        const r = enviarEscaneo(a, c);
        if (r !== 'ok') toast(mensajeResultado('IR', r));
        return true;
    }
    function pasoCmd(d) {
        const c = leerCmd(); if (!c) { toast('Comando inválido'); return; }
        cmdIn.value = h2((parseInt(c, 16) + d + 256) % 256);
        enviarActual();
    }
    function pasoDir(d) {
        const a = leerAddr(); if (!a) { toast('Dirección inválida'); return; }
        const mod = Math.pow(16, a.length);
        addrIn.value = ((parseInt(a, 16) + d + mod) % mod).toString(16).toUpperCase().padStart(a.length, '0');
        cmdIn.value = '00'; probeIdx = 0;
    }
    function detenerAuto() { if (autoTimer) { clearInterval(autoTimer); autoTimer = null; } $('sc-auto').textContent = 'Auto'; }
    function detenerBusqueda() { findToken++; $('sc-find').textContent = 'Buscar dirección (auto)'; }

    $('sc-send').addEventListener('click', enviarActual);
    $('sc-prev').addEventListener('click', () => { detenerAuto(); pasoCmd(-1); });
    $('sc-next').addEventListener('click', () => { detenerAuto(); pasoCmd(1); });
    $('sc-addr-02').addEventListener('click', () => { addrIn.value = '02'; cmdIn.value = '00'; });
    $('sc-addr-07').addEventListener('click', () => { addrIn.value = '07'; cmdIn.value = '00'; });
    $('sc-addr-prev').addEventListener('click', () => { detenerAuto(); detenerBusqueda(); pasoDir(-1); });
    $('sc-addr-next').addEventListener('click', () => { detenerAuto(); detenerBusqueda(); pasoDir(1); });

    $('sc-auto').addEventListener('click', () => {
        if (autoTimer) { detenerAuto(); toast('Detenido en cmd ' + cmdIn.value); return; }
        detenerBusqueda();
        $('sc-auto').textContent = 'Stop';
        const ms = parseInt($('sc-int').value, 10) || 700;
        autoTimer = setInterval(() => {
            const a = leerAddr(), c = leerCmd();
            if (!a || !c) { detenerAuto(); return; }
            enviarEscaneo(a, c);
            if (c === 'FF') { detenerAuto(); toast('Fin de comandos para esta dirección'); return; }
            cmdIn.value = h2(parseInt(c, 16) + 1);
        }, ms);
    });

    // Busca la dirección: por cada dirección envía varios comandos y tú vigilas si el equipo reacciona.
    $('sc-find').addEventListener('click', async () => {
        if ($('sc-find').textContent === 'Parar') {
            detenerBusqueda();
            toast('Parado en dir ' + addrIn.value + '. Prueba también la anterior (Dir −1) y usa "Siguiente comando típico"');
            return;
        }
        detenerAuto();
        const a0 = leerAddr();
        if (!a0 || a0.length !== 2) { toast('Para buscar usa dirección de 2 dígitos'); return; }
        const rapida = $('sc-mode').value === 'fast';
        const lista = rapida ? PROBES.slice() : Array.from({ length: 24 }, (_, i) => i * 11);
        const espera = Math.max(150, repeticiones * 105 + 60);
        const my = ++findToken;
        $('sc-find').textContent = 'Parar';
        const base = parseInt(a0, 16);
        for (let n = 0; n < 256 && my === findToken; n++) {
            const a = h2((base + n) % 256);
            addrIn.value = a; probeIdx = 0;
            for (const c of lista) {
                if (my !== findToken) break;
                cmdIn.value = h2(c);
                const r = enviarEscaneo(a, h2(c));
                if (r !== 'ok') { detenerBusqueda(); toast(mensajeResultado('IR', r)); return; }
                info.textContent = 'Probando dir ' + a + ' (' + (n + 1) + '/256) · ' + proto() + '\ncmd ' + h2(c);
                await sleep(espera);
            }
            await sleep(500);
        }
        if (my === findToken) { detenerBusqueda(); toast('Búsqueda terminada sin parar. Prueba con el otro protocolo'); }
    });

    // Recorre uno a uno los comandos típicos en la dirección actual (para identificar cuál reaccionó).
    $('sc-probe').addEventListener('click', () => {
        detenerAuto(); detenerBusqueda();
        const c = PROBES[probeIdx % PROBES.length];
        cmdIn.value = h2(c);
        enviarActual();
        info.textContent += '\ntípico ' + (probeIdx % PROBES.length + 1) + '/' + PROBES.length;
        probeIdx++;
    });

    $('sc-assign').addEventListener('click', () => {
        const a = leerAddr(), c = leerCmd();
        if (!a || !c) { toast('Dirección y comando inválidos'); return; }
        const k = sel.value, cod = proto() + ':' + a + ':' + c;
        const o = leerOverrides(); o[k] = cod; guardarOverrides(o);
        toast(k + ' = ' + cod + ' guardado');
    });
});

package com.example.maxg55remote

import android.content.Context
import android.hardware.ConsumerIrManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.webkit.JavascriptInterface
import kotlin.math.abs

/** Puente JS → emisor IR y vibración. En JS se usa como window.AndroidIR */
class IrBridge(private val ctx: Context, private val ir: ConsumerIrManager?) {

    private val vibrator: Vibrator? by lazy {
        try {
            if (Build.VERSION.SDK_INT >= 31) {
                (ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                ctx.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }
        } catch (e: Exception) {
            null
        }
    }

    @JavascriptInterface
    fun hasEmitter(): Boolean = ir?.hasIrEmitter() == true

    /** Texto de diagnóstico para mostrar en pantalla. */
    @JavascriptInterface
    fun info(): String {
        val sb = StringBuilder()
        sb.append("Android ").append(Build.VERSION.RELEASE).append(" · ")
            .append(Build.MANUFACTURER).append(' ').append(Build.MODEL).append('\n')
        val mgr = ir
        if (mgr == null) {
            sb.append("Servicio IR: no disponible")
            return sb.toString()
        }
        sb.append("Emisor IR: ").append(if (mgr.hasIrEmitter()) "sí" else "NO").append('\n')
        try {
            val r = mgr.carrierFrequencies
            if (r != null && r.isNotEmpty()) {
                sb.append("Portadoras: ").append(r.joinToString(", ") { "${it.minFrequency}-${it.maxFrequency} Hz" })
            } else {
                sb.append("Portadoras: no informadas")
            }
        } catch (e: Exception) {
            sb.append("Portadoras: error (").append(e.message).append(")")
        }
        sb.append('\n').append("Vibrador: ").append(if (vibrator?.hasVibrator() == true) "sí" else "no")
        return sb.toString()
    }

    private fun pickCarrier(mgr: ConsumerIrManager): Int {
        val want = SamsungIr.CARRIER_HZ
        val ranges = try { mgr.carrierFrequencies } catch (e: Exception) { null }
        if (ranges == null || ranges.isEmpty()) return want
        for (r in ranges) if (want in r.minFrequency..r.maxFrequency) return want
        var best = ranges[0].minFrequency
        var dist = Int.MAX_VALUE
        for (r in ranges) for (f in intArrayOf(r.minFrequency, r.maxFrequency)) {
            val d = abs(f - want)
            if (d < dist) { dist = d; best = f }
        }
        return best
    }

    private fun transmit(pattern: IntArray): String {
        val mgr = ir
        if (mgr == null || !mgr.hasIrEmitter()) return "no_emitter"
        return try {
            mgr.transmit(pickCarrier(mgr), pattern)
            "ok"
        } catch (e: Exception) {
            "error:" + (e.message ?: e.javaClass.simpleName)
        }
    }

    /** hex "0xE0E040BF" (notación en el aire). Devuelve ok | warn_checksum | bad_hex | no_emitter | error:... */
    @JavascriptInterface
    fun send(hex: String): String {
        val v = hex.trim().removePrefix("0x").removePrefix("0X")
        if (v.length != 8 || !v.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) return "bad_hex"
        val n = v.toLong(16)
        val b0 = ((n shr 24) and 0xFF).toInt()
        val b1 = ((n shr 16) and 0xFF).toInt()
        val b2 = ((n shr 8) and 0xFF).toInt()
        val b3 = (n and 0xFF).toInt()
        val r = transmit(SamsungIr.encodeWire(b0, b1, b2, b3))
        return if (r == "ok" && (b2 xor b3) != 0xFF) "warn_checksum" else r
    }

    /** 4 bytes (LSB primero) con temporización "S32" o "NEC". Lo usan el explorador y los códigos PROTO:DIR:CMD. */
    @JavascriptInterface
    fun sendProto(proto: String, b0: Int, b1: Int, b2: Int, b3: Int): String =
        transmit(SamsungIr.encodeBytes(proto, b0, b1, b2, b3))

    /** Vibración corta al tocar: kind = click | tick | heavy | error */
    @JavascriptInterface
    fun haptic(kind: String) {
        val v = vibrator ?: return
        try {
            if (!v.hasVibrator()) return
            when (kind) {
                "error" -> pattern(v, longArrayOf(0, 35, 70, 35))
                "heavy" -> one(v, 45, 255)
                "tick" -> one(v, 14, 120)
                else -> one(v, 26, 180)
            }
        } catch (e: Exception) {
            // ignorar
        }
    }

    private fun one(v: Vibrator, ms: Long, amp: Int) {
        if (Build.VERSION.SDK_INT >= 26) {
            val a = if (v.hasAmplitudeControl()) amp else VibrationEffect.DEFAULT_AMPLITUDE
            v.vibrate(VibrationEffect.createOneShot(ms, a))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(ms)
        }
    }

    private fun pattern(v: Vibrator, p: LongArray) {
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createWaveform(p, -1))
        } else {
            @Suppress("DEPRECATION")
            v.vibrate(p, -1)
        }
    }
}

package com.example.maxg55remote

/**
 * Codificador de tramas IR (portadora 38 kHz) para Samsung32 y NEC.
 * Samsung32: cabecera 4500/4500 µs. NEC: cabecera 9000/4500 µs.
 * Bits: marca 560 µs + espacio 1690 (=1) / 560 (=0). Termina con marca final y un silencio.
 */
object SamsungIr {
    const val CARRIER_HZ = 38000
    private const val BIT_MARK = 560
    private const val ONE_SPACE = 1690
    private const val ZERO_SPACE = 560
    private const val TRAILING_GAP = 40000   // silencio final (deja el patrón con longitud par)

    private fun build(hdrMark: Int, hdrSpace: Int, bytes: IntArray, msbFirst: Boolean): IntArray {
        val p = ArrayList<Int>(72)
        p += hdrMark; p += hdrSpace
        for (b in bytes) {
            val order = if (msbFirst) 7 downTo 0 else 0..7
            for (i in order) {
                p += BIT_MARK
                p += if ((b shr i) and 1 == 1) ONE_SPACE else ZERO_SPACE
            }
        }
        p += BIT_MARK
        p += TRAILING_GAP
        return p.toIntArray()
    }

    /** Notación 0xAABBCCDD "en el aire" (MSB primero), cabecera Samsung32. */
    fun encodeWire(b0: Int, b1: Int, b2: Int, b3: Int): IntArray =
        build(4500, 4500, intArrayOf(b0, b1, b2, b3), msbFirst = true)

    /** 4 bytes ya calculados, enviados LSB primero. proto = "S32" o "NEC". */
    fun encodeBytes(proto: String, b0: Int, b1: Int, b2: Int, b3: Int): IntArray {
        val bytes = intArrayOf(b0 and 0xFF, b1 and 0xFF, b2 and 0xFF, b3 and 0xFF)
        return if (proto == "NEC") build(9000, 4500, bytes, false) else build(4500, 4500, bytes, false)
    }
}
